<?php

$conn = new mysqli('localhost','u899171802_root','3+u5zG8H~z','u899171802_website');

?>